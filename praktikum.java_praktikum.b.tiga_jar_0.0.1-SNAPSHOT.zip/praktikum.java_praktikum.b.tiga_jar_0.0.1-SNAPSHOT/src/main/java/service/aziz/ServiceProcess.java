/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service.aziz;

/**
 *
 * @author Lenovo
 */
public class ServiceProcess {
    
    public String tampilNama(){
        return "Azizah";
    }
    public String tampilNIM(){
        return "20200140059";
    }
    public String tampilAngkatan(){
        return "2020";
    }
    public String cekNama(){
        String nama = tampilNama();
        String validasi = "";
        
        if (nama.equals("Aziz")){
            validasi = "Ini laptop saya.";
        }else{
            validasi = "Kamu siapa?";
        }
        return validasi;
    }
    public String cekAngka(int number){
        String jenis = "";
        
        if (number%2==0){
            jenis = "genap";
        }else{
            jenis = "ganjil";
        }
        return jenis;
    }
}