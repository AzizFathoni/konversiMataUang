/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package praktikum.java.praktikum.b.tiga;

import java.text.DecimalFormat;

/**
 *
 * @author Lenovo
 */
public class logicalProcess {
    
        public String getHello(){
        return"Hello World";
    }
    
    public int getJarak(int meter){
        
        int km = meter/1000;
        
        return km;
    }
    
    public double getLuasPP(){
        
        double hasil = 5.000;
               
        String pattern = "#0.00";
        DecimalFormat formatdesimal = new DecimalFormat(pattern);
        
        String a = formatdesimal.format(hasil);
        
        double parsingnumber = Double.parseDouble(a);
        
        return parsingnumber;
    }
}
