/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package praktikum.java.praktikum.b.tiga;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import service.aziz.ServiceProcess;
/**
 *
 * @author Lenovo
 */

@Controller
@ResponseBody
public class projectController {
    
        @RequestMapping("/looping")
    public String getPerulangan(){
        String hasil = "";
        for(int count = 13; count <= 100; count = count + 5){
            hasil += " angka : " + count + "<br>";
        }
        return hasil;
    }
    
    @RequestMapping("/convertion")
    public String getMatauang(){
        String konversi = " ";
        
        double rp = 17500;
        double dolar = 53;
        double rm = 350;
        
        double matauang;
        
        String pilih = "dolartorp"; //pilihan untuk dikonversi
        
        if (pilih == "rptorm"){ //rp to rm
            matauang = rp/3409.14;
            konversi = "jumlah ringgit = " + matauang;
        }else if (pilih == "dolartorp"){ //usd to idr
            matauang = dolar*14144;
            konversi = "jumlah rupiah : " + matauang;
        }else{
            konversi = "tidak ditemukan";
        }
        return konversi;
    }
    
    @RequestMapping("perhitungan")
    public String getHasil(){
        String hasil = "";
        
        int angka1 =2;
        int angka2 =5;
        
        int hitung = angka1 * angka2; //proses komputasi
        
        hasil = "Hasil perkalian = " + hitung;
        
        return hasil;
    }
    
    logicalProcess logic = new logicalProcess();
    
    @RequestMapping("/tampilanhello")
    public String tampilkan(){
        String view = logic.getHello(); //proses untuk memanggil si getHello
        
        return view;
    }
    
    @RequestMapping("/tampilanjarak")
    public String tampiljarak(){
        
        int jarak = logic.getJarak(36000);
        
        String view = "Hasil = " + jarak;
        
        return view;
    }
    
    @RequestMapping("/tampilanformatting")
    public String tampilkanjarak(){
        
        double jarak = logic.getLuasPP();
        
        String view = "Hasil = " + jarak;
        
        return view;
    }
    
    ServiceProcess aziz = new ServiceProcess(); //inisialisasi class serviceprocess
    @RequestMapping("/tampiluser")
    public String viewUser(){
        String nama, nim, angkatan, validasi, tampilkan;
        
        nama = aziz.tampilNama(); //nama = "Aziz"
        nim = aziz.tampilNIM();
        angkatan = aziz.tampilAngkatan();
        validasi = aziz.cekNama();
                
        tampilkan = nama + " " + nim + " " + angkatan + ", " + validasi;
        
        return tampilkan;
    }
}